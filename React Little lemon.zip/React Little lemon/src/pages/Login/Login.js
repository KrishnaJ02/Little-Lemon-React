import React from "react";
import UnderConstruction from "../Sections/UnderConstruction/UnderConstruction";

const Login = () => {
  return (
    <UnderConstruction />
  );
};
export default Login;
