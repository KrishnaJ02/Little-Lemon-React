import React from "react";
import UnderConstruction from "../Sections/UnderConstruction/UnderConstruction";

const Menu = () => {
  return (
    <UnderConstruction />
  );
};
export default Menu;
