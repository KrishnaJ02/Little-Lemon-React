import React from "react";
import UnderConstruction from "../Sections/UnderConstruction/UnderConstruction";

const Orders = () => {
  return (
    <UnderConstruction />
  );
};

export default Orders;